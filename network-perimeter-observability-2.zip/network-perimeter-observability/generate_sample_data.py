"""Generate a realistic, reproducible sample log file: data/sample_logs.csv

Run it with:   python generate_sample_data.py

The file holds one day of traffic for a small company network:
  * lots of normal web, application, database and DNS traffic,
  * background internet noise that gets blocked,
  * five planted attack scenarios, so every detection rule has something to find.

Public addresses come from the documentation ranges (203.0.113.0/24,
198.51.100.0/24, 192.0.2.0/24), so no real organisation is involved.
"""

from __future__ import annotations

import csv
import random
from datetime import datetime, timedelta
from pathlib import Path

rng = random.Random(42)  # fixed seed = same file every time
START = datetime(2026, 10, 31, 0, 0, 0)
OUTPUT = Path(__file__).parent / "data" / "sample_logs.csv"

WEB_SERVERS = ["10.0.1.10", "10.0.1.11"]
APP_HOSTS = [f"10.0.2.{n}" for n in range(10, 20)]
DB_SERVER = "10.0.3.5"
CUSTOMERS = [f"203.0.113.{n}" for n in range(10, 40)]
INTERNET_NOISE = [f"198.51.100.{n}" for n in range(100, 112)]
EXTERNAL_SERVICES = ["192.0.2.10", "192.0.2.20", "192.0.2.30", "192.0.2.40"]

# Busier during working hours.
HOUR_WEIGHTS = [2, 1, 1, 1, 1, 2, 3, 5, 8, 10, 10, 10, 9, 10, 10, 10, 9, 8, 6, 5, 4, 3, 3, 2]

rows: list[dict] = []


def add(when, src, src_port, dst, dst_port, protocol, action, size, packets):
    rows.append(
        {
            "timestamp": when.strftime("%Y-%m-%d %H:%M:%S"),
            "src_ip": src,
            "dst_ip": dst,
            "src_port": src_port,
            "dst_port": dst_port,
            "protocol": protocol,
            "action": action,
            "bytes": size,
            "packets": packets,
        }
    )


def random_time() -> datetime:
    hour = rng.choices(range(24), weights=HOUR_WEIGHTS)[0]
    return START + timedelta(hours=hour, minutes=rng.randint(0, 59), seconds=rng.randint(0, 59))


def ephemeral_port() -> int:
    return rng.randint(32768, 60999)


def flow_size(mu: float, cap: int) -> int:
    return max(60, min(cap, int(rng.lognormvariate(mu, 1.0))))


def packets_for(size: int) -> int:
    return max(1, size // 900 + rng.randint(0, 3))


# ---------------------------------------------------------------- normal traffic
for _ in range(1800):  # customers visiting the websites
    size = flow_size(8.5, 2_000_000)
    port = 443 if rng.random() < 0.8 else 80
    add(random_time(), rng.choice(CUSTOMERS), ephemeral_port(), rng.choice(WEB_SERVERS),
        port, "TCP", "ACCEPT", size, packets_for(size))

for _ in range(700):  # application servers calling external services
    size = flow_size(9.0, 1_500_000)
    kind = rng.random()
    if kind < 0.7:
        port, proto = 443, "TCP"
    elif kind < 0.9:
        port, proto = 53, "UDP"
        size = rng.randint(70, 300)
    else:
        port, proto = 123, "UDP"
        size = 90
    add(random_time(), rng.choice(APP_HOSTS), ephemeral_port(), rng.choice(EXTERNAL_SERVICES),
        port, proto, "ACCEPT", size, packets_for(size))

for _ in range(500):  # application servers talking to the database
    size = flow_size(9.5, 5_000_000)
    add(random_time(), rng.choice(APP_HOSTS), ephemeral_port(), DB_SERVER,
        5432, "TCP", "ACCEPT", size, packets_for(size))

for _ in range(300):  # web servers calling the application tier
    size = flow_size(8.8, 1_000_000)
    add(random_time(), rng.choice(WEB_SERVERS), ephemeral_port(), rng.choice(APP_HOSTS),
        8080, "TCP", "ACCEPT", size, packets_for(size))

for _ in range(60):  # harmless pings
    add(random_time(), rng.choice(CUSTOMERS), 0, rng.choice(WEB_SERVERS),
        0, "ICMP", "ACCEPT", 84, 1)

# Background internet noise: a few blocked probes from many addresses.
for noise_ip in INTERNET_NOISE:
    for _ in range(rng.randint(5, 9)):
        add(random_time(), noise_ip, ephemeral_port(), rng.choice(WEB_SERVERS + APP_HOSTS),
            rng.choice([22, 23, 3389, 8080, 5900, 445, 1433, 3306, 6379, 9200]),
            "TCP", "REJECT", 44, 1)

# ---------------------------------------------------------------- attack scenarios
# A. Port scan: one address tries 35 different ports in under 3 minutes.
SCAN_PORTS = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995,
              1433, 1521, 3306, 3389, 5432, 5900, 6379, 8000, 8080, 8443, 9200, 27017,
              2049, 5060, 8888, 9000, 10000, 11211, 5984, 7001]
scan_start = START + timedelta(hours=3, minutes=12)
for i, port in enumerate(SCAN_PORTS):
    open_port = port in (80, 443)
    add(scan_start + timedelta(seconds=5 * i), "203.0.113.66", ephemeral_port(), "10.0.1.10",
        port, "TCP", "ACCEPT" if open_port else "REJECT", 120 if open_port else 44, 2 if open_port else 1)

# B. SSH password guessing against a server whose firewall wrongly allows SSH from anywhere.
ssh_start = START + timedelta(hours=9, minutes=40, seconds=30)
for i in range(40):
    add(ssh_start + timedelta(seconds=6 * i), "198.51.100.23", ephemeral_port(), "10.0.1.25",
        22, "TCP", "ACCEPT", rng.randint(2500, 4200), rng.randint(18, 30))

# C. RDP password guessing that the firewall blocks.
rdp_start = START + timedelta(hours=16, minutes=5, seconds=10)
for i in range(30):
    add(rdp_start + timedelta(seconds=7 * i), "192.0.2.150", ephemeral_port(), "10.0.1.10",
        3389, "TCP", "REJECT", 52, 1)

# D. Slow, persistent prober: 30 attempts spread across the whole day, almost all blocked.
for i in range(30):
    when = START + timedelta(minutes=47 * i + rng.randint(0, 30))
    add(when, "198.51.100.200", ephemeral_port(), "10.0.1.11",
        [8080, 8443, 9200][i % 3], "TCP", "ACCEPT" if i in (7, 19) else "REJECT", 60, 1)

# E. Data theft: an internal server uploads about 100 MB to one external address.
exfil_start = START + timedelta(hours=14, minutes=20)
for i in range(12):
    size = rng.randint(7_500_000, 9_500_000)
    add(exfil_start + timedelta(seconds=20 * i), "10.0.2.14", ephemeral_port(), "192.0.2.88",
        443, "TCP", "ACCEPT", size, size // 1400)

# F. A database port open to the internet, and someone using it.
db_start = START + timedelta(hours=11, minutes=30)
for i in range(6):
    add(db_start + timedelta(seconds=40 * i), "198.51.100.77", ephemeral_port(), DB_SERVER,
        3306, "TCP", "ACCEPT", rng.randint(3000, 9000), rng.randint(10, 25))

# ---------------------------------------------------------------- write the file
rows.sort(key=lambda r: r["timestamp"])
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with OUTPUT.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

print(f"Wrote {len(rows)} log rows to {OUTPUT}")
