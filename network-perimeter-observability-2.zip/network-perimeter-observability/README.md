# Securing Network Perimeter Through Observability

A local security dashboard that analyses network traffic logs, shows which connections
were allowed or blocked, detects suspicious IP activity and raises security alerts.

Built with **Python, Streamlit, Pandas and Plotly**. It runs entirely on your laptop and
needs **no AWS account**.

## Status

| Part | Status |
|---|---|
| Local dashboard, CSV upload, sample data | Built. Unit tests cover the loader, detection rules, alerts and sample data. |
| AWS CloudWatch Logs integration | **Not implemented.** Planned for a later phase. |
| AWS Security Group integration | **Not implemented.** Planned for a later phase. |

The loader already understands AWS VPC Flow Log column names (`srcaddr`, `dstaddr`,
`dstport`, `start`...) in a CSV file, which prepares the ground for CloudWatch later.
That is file parsing only, not a connection to AWS.

## Folder structure

```
network-perimeter-observability/
├── app.py                    Streamlit dashboard (the page you open)
├── generate_sample_data.py   Recreates data/sample_logs.csv
├── requirements.txt          Python packages to install
├── README.md                 This file
├── data/
│   └── sample_logs.csv       3,593 realistic sample log rows (one day)
├── src/
│   ├── log_loader.py         Reads and validates CSV logs
│   ├── detector.py           The five detection rules
│   ├── alerts.py             Alerts, advice and per-IP risk score
│   ├── metrics.py            Headline numbers
│   └── charts.py             Plotly charts
└── tests/
    ├── helpers.py            Test helper
    ├── test_loader.py        Loader tests
    └── test_detector.py      Detection, alert and sample-data tests
```

## Install on Windows 11 (first time only)

1. **Install Python 3.10 or newer** from https://www.python.org/downloads/ . On the first
   installer screen tick **Add python.exe to PATH**, then click Install Now.
2. **Install VS Code** from https://code.visualstudio.com/ and add the **Python**
   extension (Extensions icon in the left bar, search "Python", Install).
3. **Open the project in VS Code:** File > Open Folder > choose `network-perimeter-observability`.
4. **Open a terminal in VS Code:** Terminal > New Terminal (it opens PowerShell in the project folder).
5. **Create a virtual environment** (a private box for this project's packages):

   ```powershell
   python -m venv venv
   ```

6. **Activate it:**

   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

   You should now see `(venv)` at the start of the line.

   If PowerShell says "running scripts is disabled", run this once and try again:

   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
   ```

7. **Install the packages:**

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

8. If VS Code asks which interpreter to use, choose the one inside `venv`
   (Ctrl+Shift+P > "Python: Select Interpreter").

## Run the dashboard

With `(venv)` showing in the terminal:

```powershell
streamlit run app.py
```

Your browser opens at http://localhost:8501 . If it does not, open that address yourself.
Stop the dashboard with **Ctrl+C** in the terminal.

Next time you only need steps 3, 4, 6 (activate) and this command.

## Run the automated tests

```powershell
python -m unittest discover -v
```

All tests should end with `OK`.

## How to test every feature in the dashboard

| Feature | What to do | What you should see |
|---|---|---|
| Sample dataset | Open the app. The sidebar shows **Sample dataset**. | Six cards at the top: 3,593 connections, 3,422 allowed, 171 blocked, 9 open alerts. |
| Network activity monitoring | **Overview** tab. | Line chart of connections over time, top 10 source IPs, top 10 destination ports. |
| Allowed and blocked | Look at the donut chart. In the sidebar, untick **Allowed**. | Only blocked traffic remains. The cards and charts update. Re-tick it afterwards. |
| Direction and data volume | **Traffic analysis** tab. | Inbound, outbound and internal counts, a data volume chart with a spike in the 14:00 hour, and a table of blocked connections by service. |
| Suspicious IP detection | **Suspicious IPs** tab. | Six IPs ranked by risk score. `198.51.100.23` is first (score 65). Pick an IP in **Investigate an IP address** to see its connections. |
| Security alerts | **Security alerts** tab. | Nine alerts: 1 Critical, 5 High, 3 Medium. Open one to read what happened and the recommended action. |
| Alert filtering | Untick severities under **Show severities**. | The alert table shrinks to match. |
| Alert export | Click **Download alerts as CSV**. | A `security_alerts.csv` file downloads. |
| Adjustable thresholds | Sidebar > **Detection thresholds**. Raise **Port scan: different ports** to 40. | The Port Scan alert disappears. Set it back to 15 and it returns. |
| Direction and protocol filters | Sidebar filters. | Charts and tables follow your choices. Alerts do not change, because they always use every row. |
| CSV upload | Select **Upload CSV**, click **Download the sample CSV as a template**, then upload that file. | The same results as the sample dataset. |
| Bad file handling | Upload a text file renamed to `.csv`, or a CSV without an `action` column. | A clear red error naming the missing column. |
| Log table and export | **Log table** tab. | All rows (respecting filters) and a **Download filtered logs as CSV** button. |

### The five attack scenarios hidden in the sample data

| Rule | Source | What happens | Severity |
|---|---|---|---|
| Port Scan | 203.0.113.66 | Tries 35 ports in under 3 minutes at 03:12 | High |
| Brute Force | 198.51.100.23 | 40 SSH attempts, all allowed, at 09:40 | Critical |
| Brute Force | 192.0.2.150 | 30 RDP attempts, all blocked, at 16:05 | High |
| Data Exfiltration | 10.0.2.14 | Sends about 100 MB to 192.0.2.88 at 14:20 | High |
| Exposed Sensitive Port | 198.51.100.77, 198.51.100.23 | Internet reaches MySQL (3306) and SSH (22) | High |
| High Block Rate | three IPs | Nearly all connections blocked | Medium |

## CSV format for your own logs

Required columns: `timestamp`, `src_ip`, `dst_ip`, `dst_port`, `protocol`, `action`.
Optional columns: `src_port`, `bytes`, `packets`.

```csv
timestamp,src_ip,dst_ip,src_port,dst_port,protocol,action,bytes,packets
2026-10-31 03:12:00,203.0.113.66,10.0.1.10,51234,22,TCP,REJECT,44,1
```

- `timestamp`: a date and time (read as UTC), or epoch seconds.
- `protocol`: `TCP`, `UDP`, `ICMP` or the numbers 6, 17, 1.
- `action`: `ACCEPT`/`ALLOW` count as Allowed. `REJECT`/`DENY`/`DROP`/`BLOCK` count as Blocked.
- Addresses starting 10., 172.16-31. and 192.168. are treated as inside your network.
- Rows that cannot be understood are skipped, and the dashboard tells you how many.

## How the detection rules work

| Rule | Triggers when | Severity |
|---|---|---|
| Port Scan | One IP touches 15 or more different ports within 5 minutes | High |
| Brute Force | 10 or more attempts from one IP to SSH, RDP or Telnet within 5 minutes | Critical if any were allowed, otherwise High |
| High Block Rate | An IP has 20 or more connections and 80% or more are blocked | Medium |
| Data Exfiltration | An internal host sends 50 MB or more to the internet within 5 minutes | High |
| Exposed Sensitive Port | An internet address is allowed through to SSH, RDP, Telnet, SMB, MySQL, PostgreSQL or MSSQL | High |

All thresholds can be changed in the sidebar. Risk score per IP: Critical 40 points,
High 25, Medium 10, Low 5, capped at 100.

These are simple rules meant for learning and for a first look at your logs. They are not
a replacement for a commercial intrusion detection system.

## Regenerate the sample data

```powershell
python generate_sample_data.py
```

The data is created with a fixed random seed, so you always get the same file.

## Troubleshooting

| Problem | Fix |
|---|---|
| `python` is not recognised | Reinstall Python and tick **Add python.exe to PATH**. Reopen the terminal. |
| `streamlit` is not recognised | Activate the venv first: `.\venv\Scripts\Activate.ps1`. |
| `ModuleNotFoundError: No module named 'plotly'` | You are outside the venv, or skipped `pip install -r requirements.txt`. |
| Port 8501 already in use | `streamlit run app.py --server.port 8502` |
| Sample file not found | Run `python generate_sample_data.py`. |

## Roadmap (not built yet)

1. **CloudWatch Logs:** read VPC Flow Logs with `boto3` and feed them into the same loader.
2. **Security Groups:** list your security groups, flag rules open to `0.0.0.0/0`, and
   suggest tighter rules from what the logs show.

These two steps need an AWS account and credentials, and will be marked complete only
after they are written and tested against a real account.
