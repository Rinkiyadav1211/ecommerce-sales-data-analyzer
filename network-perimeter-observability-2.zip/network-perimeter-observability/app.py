"""Securing Network Perimeter Through Observability: Streamlit dashboard.

Start it with:   streamlit run app.py
"""

from __future__ import annotations

import inspect
import io
from pathlib import Path

import pandas as pd
import streamlit as st

from src.alerts import SEVERITY_ORDER, build_alerts, risk_by_ip
from src.charts import (
    data_volume_over_time,
    severity_chart,
    status_donut,
    top_ports,
    top_sources,
    traffic_by_direction,
    traffic_over_time,
)
from src.detector import DetectionConfig, run_detection
from src.log_loader import REQUIRED_COLUMNS, LogFormatError, load_logs
from src.metrics import traffic_summary

SAMPLE_PATH = Path(__file__).parent / "data" / "sample_logs.csv"
SEVERITY_ICONS = {"Critical": "🔴", "High": "🟠", "Medium": "🟡", "Low": "🔵"}

st.set_page_config(
    page_title="Network Perimeter Observability",
    page_icon="🛡️",
    layout="wide",
)


def _stretch_option(func) -> dict:
    """Full-width option name differs between Streamlit versions; pick the right one."""
    if "use_container_width" in inspect.signature(func).parameters:
        return {"use_container_width": True}
    return {"width": "stretch"}


TABLE_WIDTH = _stretch_option(st.dataframe)
CHART_WIDTH = _stretch_option(st.plotly_chart)


def show_chart(figure) -> None:
    st.plotly_chart(figure, **CHART_WIDTH)


def show_table(data: pd.DataFrame, **options) -> None:
    st.dataframe(data, hide_index=True, **TABLE_WIDTH, **options)


st.markdown(
    """
    <style>
    .block-container {padding-top: 1.6rem; max-width: 1400px;}
    .banner {background: #0F2747; color: #FFFFFF; padding: 1.1rem 1.5rem;
             border-radius: 10px; margin-bottom: 1.2rem;}
    .banner h1 {margin: 0; padding: 0; font-size: 1.6rem; color: #FFFFFF;}
    .banner p {margin: .35rem 0 0; color: #C9D6EA; font-size: .95rem;}
    </style>
    <div class="banner">
        <h1>Securing Network Perimeter Through Observability</h1>
        <p>See what crosses your network edge, what gets blocked, and who looks suspicious.</p>
    </div>
    """,
    unsafe_allow_html=True,
)


# ----------------------------------------------------------------------- loading
@st.cache_data(show_spinner=False)
def load_sample():
    return load_logs(SAMPLE_PATH)


@st.cache_data(show_spinner="Reading your file...")
def load_upload(content: bytes):
    return load_logs(io.BytesIO(content))


@st.cache_data(show_spinner=False)
def detect(df, window, ports, attempts, min_events, ratio, exfil_mb):
    config = DetectionConfig(
        window_minutes=window,
        port_scan_min_ports=ports,
        brute_force_min_attempts=attempts,
        blocked_ratio_min_events=min_events,
        blocked_ratio_threshold=ratio,
        exfil_min_bytes=int(exfil_mb * 1_000_000),
    )
    return run_detection(df, config)


with st.sidebar:
    st.header("Log source")
    source = st.radio(
        "Choose logs",
        ["Sample dataset", "Upload CSV"],
        label_visibility="collapsed",
    )
    uploaded = None
    if source == "Upload CSV":
        uploaded = st.file_uploader("CSV log file", type=["csv"])
        st.caption("Required columns: " + ", ".join(REQUIRED_COLUMNS))
        if SAMPLE_PATH.exists():
            st.download_button(
                "Download the sample CSV as a template",
                data=SAMPLE_PATH.read_bytes(),
                file_name="sample_logs.csv",
                mime="text/csv",
            )

try:
    if source == "Sample dataset":
        result = load_sample()
    else:
        if uploaded is None:
            st.info("Upload a CSV log file in the sidebar to begin, or switch to the sample dataset.")
            st.stop()
        result = load_upload(uploaded.getvalue())
except FileNotFoundError:
    st.error(
        "Sample file not found. Run `python generate_sample_data.py` in the project folder, "
        "then refresh this page."
    )
    st.stop()
except LogFormatError as problem:
    st.error(f"Could not use this file. {problem}")
    st.stop()

logs = result.data
if result.rows_dropped:
    st.warning(
        f"{result.rows_dropped:,} of {result.rows_read:,} rows were skipped because of "
        "invalid timestamps, IP addresses, ports or actions."
    )

with st.sidebar:
    st.header("Filters")
    st.caption("Filters change the charts and tables. Alerts always use all rows.")
    status_choice = st.multiselect("Connection status", ["Allowed", "Blocked"], default=["Allowed", "Blocked"])
    direction_options = sorted(logs["direction"].unique())
    direction_choice = st.multiselect("Direction", direction_options, default=direction_options)
    protocol_options = sorted(logs["protocol"].unique())
    protocol_choice = st.multiselect("Protocol", protocol_options, default=protocol_options)

    with st.expander("Detection thresholds"):
        window = st.slider("Time window (minutes)", 1, 30, 5)
        ports = st.slider("Port scan: different ports", 5, 100, 15)
        attempts = st.slider("Brute force: attempts", 3, 100, 10)
        min_events = st.slider("High block rate: minimum connections", 5, 100, 20)
        ratio = st.slider("High block rate: blocked share", 0.5, 1.0, 0.8, 0.05)
        exfil_mb = st.slider("Data exfiltration: MB per window", 10, 500, 50)

view = logs[
    logs["status"].isin(status_choice)
    & logs["direction"].isin(direction_choice)
    & logs["protocol"].isin(protocol_choice)
]

findings = detect(logs, window, ports, attempts, min_events, ratio, exfil_mb)
alerts = build_alerts(findings)
risk = risk_by_ip(alerts)

# ------------------------------------------------------------------ summary cards
summary = traffic_summary(view)
cards = [
    ("Connections", f"{summary['total']:,}"),
    ("Allowed", f"{summary['allowed']:,}"),
    ("Blocked", f"{summary['blocked']:,}"),
    ("Block rate", f"{summary['block_rate']:.1%}"),
    ("Source IPs", f"{summary['unique_sources']:,}"),
    ("Open alerts", f"{len(alerts):,}"),
]
for column, (label, value) in zip(st.columns(len(cards)), cards):
    with column.container(border=True):
        st.metric(label, value)

tab_overview, tab_traffic, tab_ips, tab_alerts, tab_logs = st.tabs(
    ["Overview", "Traffic analysis", "Suspicious IPs", "Security alerts", "Log table"]
)

# ---------------------------------------------------------------------- overview
with tab_overview:
    if view.empty:
        st.warning("No connections match the current filters. Adjust them in the sidebar.")
    else:
        left, right = st.columns([2, 1])
        with left:
            show_chart(traffic_over_time(view))
        with right:
            show_chart(status_donut(view))
        left, right = st.columns(2)
        with left:
            show_chart(top_sources(view))
        with right:
            show_chart(top_ports(view))

# ------------------------------------------------------------------- traffic tab
with tab_traffic:
    if view.empty:
        st.warning("No connections match the current filters. Adjust them in the sidebar.")
    else:
        left, right = st.columns(2)
        with left:
            show_chart(traffic_by_direction(view))
        with right:
            show_chart(data_volume_over_time(view))

        st.subheader("Blocked connections by service")
        blocked = view[view["status"] == "Blocked"]
        if blocked.empty:
            st.success("No blocked connections in the current view.")
        else:
            by_service = (
                blocked.groupby(["dst_port", "service"])
                .agg(blocked=("status", "size"), unique_sources=("src_ip", "nunique"))
                .reset_index()
                .sort_values("blocked", ascending=False)
            )
            show_table(by_service)

# --------------------------------------------------------------- suspicious IPs
with tab_ips:
    if risk.empty:
        st.success("No suspicious IP addresses with the current thresholds.")
    else:
        st.caption("Risk score: Critical alert = 40 points, High = 25, Medium = 10, Low = 5 (maximum 100).")
        show_table(
            risk,
            column_config={
                "source_ip": "Source IP",
                "risk_score": st.column_config.ProgressColumn(
                    "Risk score", min_value=0, max_value=100, format="%d"
                ),
                "alert_count": "Alerts",
                "highest_severity": "Highest severity",
                "rules": "Triggered rules",
            },
        )

        st.subheader("Investigate an IP address")
        chosen_ip = st.selectbox("Source IP", risk["source_ip"])
        ip_logs = logs[logs["src_ip"] == chosen_ip]
        ip_summary = traffic_summary(ip_logs)
        first, second, third, fourth = st.columns(4)
        first.metric("Connections", f"{ip_summary['total']:,}")
        second.metric("Allowed", f"{ip_summary['allowed']:,}")
        third.metric("Blocked", f"{ip_summary['blocked']:,}")
        fourth.metric("Data sent (MB)", f"{ip_summary['megabytes']:,.1f}")
        show_chart(top_ports(ip_logs))
        show_table(ip_logs.drop(columns=["action"]))

# ------------------------------------------------------------------ alerts tab
with tab_alerts:
    if alerts.empty:
        st.success("No security alerts. Nothing crossed the detection thresholds.")
    else:
        counts = alerts["severity"].value_counts()
        for column, level in zip(st.columns(len(SEVERITY_ORDER)), SEVERITY_ORDER):
            with column.container(border=True):
                st.metric(f"{SEVERITY_ICONS[level]} {level}", int(counts.get(level, 0)))

        severity_choice = st.multiselect("Show severities", SEVERITY_ORDER, default=SEVERITY_ORDER)
        shown = alerts[alerts["severity"].isin(severity_choice)]

        left, right = st.columns([1, 2])
        with left:
            show_chart(severity_chart(alerts))
        with right:
            show_table(
                shown[["alert_id", "severity", "rule", "source_ip", "event_count", "last_seen"]],
                column_config={
                    "alert_id": "Alert",
                    "severity": "Severity",
                    "rule": "Rule",
                    "source_ip": "Source IP",
                    "event_count": "Events",
                    "last_seen": st.column_config.DatetimeColumn(
                        "Last seen (UTC)", format="YYYY-MM-DD HH:mm:ss"
                    ),
                },
            )

        st.subheader("Alert details")
        for alert in shown.head(50).itertuples():
            title = f"{SEVERITY_ICONS[alert.severity]} {alert.alert_id}: {alert.rule} from {alert.source_ip}"
            with st.expander(title):
                st.write(alert.details)
                st.caption(
                    f"Severity {alert.severity}. {alert.event_count} events between "
                    f"{alert.first_seen:%Y-%m-%d %H:%M:%S} and {alert.last_seen:%H:%M:%S} UTC."
                )
                st.info(f"Recommended action: {alert.recommendation}")

        st.download_button(
            "Download alerts as CSV",
            data=alerts.to_csv(index=False).encode("utf-8"),
            file_name="security_alerts.csv",
            mime="text/csv",
        )

# ---------------------------------------------------------------------- log table
with tab_logs:
    st.caption(f"{len(view):,} connections shown (all times UTC).")
    show_table(view.drop(columns=["action"]))
    st.download_button(
        "Download filtered logs as CSV",
        data=view.to_csv(index=False).encode("utf-8"),
        file_name="filtered_logs.csv",
        mime="text/csv",
    )

st.caption(
    "This prototype analyses CSV files only. AWS CloudWatch and AWS Security Group "
    "integration are planned for a later phase and are not implemented yet."
)
