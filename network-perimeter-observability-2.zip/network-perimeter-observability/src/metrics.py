"""Headline numbers shown at the top of the dashboard."""

from __future__ import annotations

import pandas as pd


def traffic_summary(df: pd.DataFrame) -> dict:
    """Return the key traffic numbers for a (possibly filtered) log DataFrame."""
    total = len(df)
    allowed = int((df["status"] == "Allowed").sum())
    blocked = int((df["status"] == "Blocked").sum())
    return {
        "total": total,
        "allowed": allowed,
        "blocked": blocked,
        "block_rate": (blocked / total) if total else 0.0,
        "unique_sources": int(df["src_ip"].nunique()),
        "unique_destinations": int(df["dst_ip"].nunique()),
        "megabytes": float(df["bytes"].sum()) / 1_000_000,
    }
