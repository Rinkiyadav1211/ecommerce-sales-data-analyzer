"""Plotly charts used by the dashboard. Each function returns a Figure."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from src.alerts import SEVERITY_ORDER

STATUS_ORDER = ["Allowed", "Blocked"]
STATUS_COLORS = {"Allowed": "#2E9E6B", "Blocked": "#D64545"}
SEVERITY_COLORS = {
    "Critical": "#8E1B1B",
    "High": "#D64545",
    "Medium": "#E8A33D",
    "Low": "#4C8BF5",
}
TEMPLATE = "plotly_white"


def _style(fig: go.Figure, title: str, height: int = 340) -> go.Figure:
    fig.update_layout(
        template=TEMPLATE,
        title=dict(text=title, font=dict(size=16)),
        height=height,
        margin=dict(l=10, r=10, t=60, b=10),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    return fig


def pick_frequency(df: pd.DataFrame) -> str:
    """Choose a time bucket size that suits how long the logs span."""
    span = df["timestamp"].max() - df["timestamp"].min()
    if span <= pd.Timedelta(hours=3):
        return "5min"
    if span <= pd.Timedelta(days=3):
        return "1h"
    return "1D"


def _binned_counts(df: pd.DataFrame, freq: str) -> pd.DataFrame:
    """Connections per time bucket for Allowed and Blocked, with empty buckets as 0."""
    bins = df["timestamp"].dt.floor(freq)
    counts = (
        df.groupby([bins, "status"])
        .size()
        .unstack("status", fill_value=0)
        .reindex(columns=STATUS_ORDER, fill_value=0)
    )
    full_range = pd.date_range(counts.index.min(), counts.index.max(), freq=freq)
    return counts.reindex(full_range, fill_value=0)


def traffic_over_time(df: pd.DataFrame) -> go.Figure:
    """Line chart of allowed vs blocked connections over time."""
    counts = _binned_counts(df, pick_frequency(df))
    fig = go.Figure()
    for status in STATUS_ORDER:
        fig.add_trace(
            go.Scatter(
                x=counts.index,
                y=counts[status],
                name=status,
                mode="lines",
                line=dict(color=STATUS_COLORS[status], width=2.5),
            )
        )
    fig.update_layout(hovermode="x unified")
    fig.update_yaxes(title_text="Connections")
    return _style(fig, "Connections over time (UTC)")


def data_volume_over_time(df: pd.DataFrame) -> go.Figure:
    """Bar chart of megabytes transferred per time bucket."""
    freq = pick_frequency(df)
    volume = (df.groupby(df["timestamp"].dt.floor(freq))["bytes"].sum() / 1_000_000).reset_index()
    volume.columns = ["time", "megabytes"]
    fig = px.bar(volume, x="time", y="megabytes")
    fig.update_traces(marker_color="#1D4E89")
    fig.update_yaxes(title_text="Megabytes")
    fig.update_xaxes(title_text=None)
    return _style(fig, "Data volume over time (MB)")


def status_donut(df: pd.DataFrame) -> go.Figure:
    """Donut chart of allowed vs blocked connections."""
    counts = df["status"].value_counts().reindex(STATUS_ORDER, fill_value=0)
    fig = go.Figure(
        go.Pie(
            labels=list(counts.index),
            values=list(counts.values),
            hole=0.6,
            marker=dict(colors=[STATUS_COLORS[s] for s in counts.index]),
            sort=False,
        )
    )
    return _style(fig, "Allowed vs blocked")


def _stacked_bar(table: pd.DataFrame, title: str) -> go.Figure:
    """Horizontal stacked bars (Allowed + Blocked) from a table indexed by label."""
    table = table.reindex(columns=STATUS_ORDER, fill_value=0)
    table = table.assign(total=table.sum(axis=1)).sort_values("total").drop(columns="total")
    fig = go.Figure()
    for status in STATUS_ORDER:
        fig.add_trace(
            go.Bar(
                y=table.index.astype(str),
                x=table[status],
                name=status,
                orientation="h",
                marker_color=STATUS_COLORS[status],
            )
        )
    fig.update_layout(barmode="stack")
    fig.update_xaxes(title_text="Connections")
    return _style(fig, title, height=380)


def top_sources(df: pd.DataFrame, n: int = 10) -> go.Figure:
    """The most active source IP addresses."""
    table = df.groupby(["src_ip", "status"]).size().unstack("status", fill_value=0)
    table = table.assign(total=table.sum(axis=1)).nlargest(n, "total").drop(columns="total")
    return _stacked_bar(table, f"Top {n} source IPs")


def top_ports(df: pd.DataFrame, n: int = 10) -> go.Figure:
    """The most targeted destination ports."""
    labelled = df.assign(port_label=df["dst_port"].astype(str) + " (" + df["service"] + ")")
    table = labelled.groupby(["port_label", "status"]).size().unstack("status", fill_value=0)
    table = table.assign(total=table.sum(axis=1)).nlargest(n, "total").drop(columns="total")
    return _stacked_bar(table, f"Top {n} destination ports")


def traffic_by_direction(df: pd.DataFrame) -> go.Figure:
    """Connections grouped by direction (inbound, outbound, internal)."""
    grouped = df.groupby(["direction", "status"]).size().reset_index(name="connections")
    fig = px.bar(
        grouped,
        x="direction",
        y="connections",
        color="status",
        barmode="group",
        color_discrete_map=STATUS_COLORS,
        category_orders={"status": STATUS_ORDER},
    )
    fig.update_xaxes(title_text=None)
    fig.update_yaxes(title_text="Connections")
    return _style(fig, "Traffic by direction")


def severity_chart(alerts: pd.DataFrame) -> go.Figure:
    """Number of alerts at each severity level."""
    counts = alerts["severity"].value_counts().reindex(SEVERITY_ORDER, fill_value=0)
    fig = go.Figure(
        go.Bar(
            x=list(counts.index),
            y=list(counts.values),
            marker_color=[SEVERITY_COLORS[s] for s in counts.index],
        )
    )
    fig.update_yaxes(title_text="Alerts", dtick=1)
    return _style(fig, "Alerts by severity", height=300)
