"""Load, validate and normalise network flow logs.

The loader accepts a CSV file (path or file-like object) and returns a clean
pandas DataFrame with one row per network connection. Rows that cannot be
understood (bad IP, bad timestamp, unknown action...) are dropped and counted so
the dashboard can tell you how many were skipped.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from functools import lru_cache

import numpy as np
import pandas as pd

# Columns every log file must contain (after alias renaming).
REQUIRED_COLUMNS = ["timestamp", "src_ip", "dst_ip", "dst_port", "protocol", "action"]

# Columns that are nice to have. Missing ones are filled with 0.
OPTIONAL_COLUMNS = ["src_port", "bytes", "packets"]

# Alternative column names (e.g. AWS VPC Flow Logs) mapped to our names.
COLUMN_ALIASES = {
    "srcaddr": "src_ip",
    "dstaddr": "dst_ip",
    "srcport": "src_port",
    "dstport": "dst_port",
    "start": "timestamp",
    "source_ip": "src_ip",
    "destination_ip": "dst_ip",
    "source_port": "src_port",
    "destination_port": "dst_port",
}

PROTOCOL_NAMES = {"1": "ICMP", "6": "TCP", "17": "UDP"}

# Every spelling of "the connection went through" / "the connection was stopped".
ACTION_MAP = {
    "ACCEPT": "Allowed",
    "ACCEPTED": "Allowed",
    "ALLOW": "Allowed",
    "ALLOWED": "Allowed",
    "PERMIT": "Allowed",
    "REJECT": "Blocked",
    "REJECTED": "Blocked",
    "DENY": "Blocked",
    "DENIED": "Blocked",
    "DROP": "Blocked",
    "BLOCK": "Blocked",
    "BLOCKED": "Blocked",
}

COMMON_PORTS = {
    20: "FTP-Data",
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    123: "NTP",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    1433: "MSSQL",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    6379: "Redis",
    8080: "HTTP-Alt",
    8443: "HTTPS-Alt",
    9200: "Elasticsearch",
    27017: "MongoDB",
}

# Private (RFC 1918) address space = "inside the network".
# Documentation ranges such as 203.0.113.0/24 are deliberately treated as
# external, so they can stand in for internet addresses in the sample data.
_INTERNAL_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
]

LOG_COLUMNS = [
    "timestamp",
    "src_ip",
    "src_port",
    "dst_ip",
    "dst_port",
    "protocol",
    "action",
    "status",
    "direction",
    "service",
    "bytes",
    "packets",
]


class LogFormatError(ValueError):
    """Raised when a log file cannot be used at all."""


@dataclass(frozen=True)
class LoadResult:
    """A cleaned DataFrame plus a little bookkeeping about the load."""

    data: pd.DataFrame
    rows_read: int
    rows_dropped: int


@lru_cache(maxsize=100_000)
def is_valid_ip(value: str) -> bool:
    """Return True if the text is a valid IPv4 or IPv6 address."""
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return False
    return True


@lru_cache(maxsize=100_000)
def is_internal_ip(value: str) -> bool:
    """Return True if the address is inside the private network ranges."""
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return False
    return any(address in network for network in _INTERNAL_NETWORKS)


def load_logs(source) -> LoadResult:
    """Read a CSV from a file path or file-like object and normalise it."""
    try:
        raw = pd.read_csv(source, dtype=str, keep_default_na=False)
    except pd.errors.EmptyDataError as exc:
        raise LogFormatError("The file is empty.") from exc
    except (pd.errors.ParserError, UnicodeDecodeError) as exc:
        raise LogFormatError(f"The file could not be read as CSV: {exc}") from exc
    return normalise_logs(raw)


def normalise_logs(raw: pd.DataFrame) -> LoadResult:
    """Validate and clean a raw DataFrame of log rows."""
    df = raw.copy()
    df.columns = [
        str(name).strip().lower().replace("-", "_").replace(" ", "_")
        for name in df.columns
    ]

    renames = {
        old: new
        for old, new in COLUMN_ALIASES.items()
        if old in df.columns and new not in df.columns
    }
    df = df.rename(columns=renames)

    missing = [name for name in REQUIRED_COLUMNS if name not in df.columns]
    if missing:
        raise LogFormatError(
            "The file is missing required column(s): "
            + ", ".join(missing)
            + ". Required columns are: "
            + ", ".join(REQUIRED_COLUMNS)
            + "."
        )

    rows_read = len(df)
    if rows_read == 0:
        raise LogFormatError("The file has a header row but no log rows.")

    for name in OPTIONAL_COLUMNS:
        if name not in df.columns:
            df[name] = "0"

    # IP addresses.
    df["src_ip"] = df["src_ip"].astype(str).str.strip()
    df["dst_ip"] = df["dst_ip"].astype(str).str.strip()

    # Timestamps: either epoch seconds (AWS style) or normal date text.
    stamp_numbers = pd.to_numeric(df["timestamp"], errors="coerce")
    if stamp_numbers.notna().mean() > 0.9:
        df["timestamp"] = pd.to_datetime(
            stamp_numbers, unit="s", utc=True, errors="coerce"
        )
    else:
        df["timestamp"] = pd.to_datetime(
            df["timestamp"], utc=True, errors="coerce", format="mixed"
        )

    # Numbers.
    for name in ["dst_port", "src_port", "bytes", "packets"]:
        df[name] = pd.to_numeric(df[name], errors="coerce")

    # Protocol names (6 -> TCP, 17 -> UDP, 1 -> ICMP).
    df["protocol"] = (
        df["protocol"].astype(str).str.strip().str.upper().replace(PROTOCOL_NAMES)
    )

    # Allowed / Blocked.
    df["action"] = df["action"].astype(str).str.strip().str.upper()
    df["status"] = df["action"].map(ACTION_MAP)

    valid = (
        df["timestamp"].notna()
        & df["status"].notna()
        & df["dst_port"].between(0, 65535)
        & df["src_ip"].map(is_valid_ip)
        & df["dst_ip"].map(is_valid_ip)
    )
    df = df[valid].copy()
    rows_dropped = rows_read - len(df)

    if df.empty:
        raise LogFormatError(
            "None of the rows were valid. Check the timestamp, IP address, "
            "port and action columns."
        )

    df["dst_port"] = df["dst_port"].astype(int)
    df["src_port"] = df["src_port"].fillna(0).clip(lower=0).astype(int)
    df["bytes"] = df["bytes"].fillna(0).clip(lower=0).astype("int64")
    df["packets"] = df["packets"].fillna(0).clip(lower=0).astype("int64")

    # Traffic direction relative to the private network.
    source_inside = df["src_ip"].map(is_internal_ip).astype(bool)
    dest_inside = df["dst_ip"].map(is_internal_ip).astype(bool)
    df["direction"] = np.select(
        [~source_inside & dest_inside, source_inside & ~dest_inside, source_inside & dest_inside],
        ["Inbound", "Outbound", "Internal"],
        default="External",
    )

    # Friendly service name for the destination port.
    df["service"] = df["dst_port"].map(COMMON_PORTS).fillna("Other")

    df = df[LOG_COLUMNS].sort_values("timestamp").reset_index(drop=True)
    return LoadResult(data=df, rows_read=rows_read, rows_dropped=rows_dropped)
