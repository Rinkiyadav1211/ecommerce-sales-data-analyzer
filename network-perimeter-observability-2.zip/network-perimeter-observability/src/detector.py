"""Rule-based detection of suspicious network activity.

Every rule looks at the cleaned log DataFrame (see log_loader.py) and returns a
list of "findings". A finding is one suspicious behaviour by one IP address.
Thresholds live in DetectionConfig so the dashboard can let you tune them.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

# Ports that should rarely be reachable from the internet.
SENSITIVE_PORTS = {
    22: "SSH",
    23: "Telnet",
    445: "SMB",
    1433: "MSSQL",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
}

# Remote administration ports, the usual targets of password guessing.
REMOTE_ADMIN_PORTS = {22, 23, 3389}

FINDING_COLUMNS = [
    "rule",
    "severity",
    "source_ip",
    "first_seen",
    "last_seen",
    "event_count",
    "details",
]


@dataclass(frozen=True)
class DetectionConfig:
    """Tunable thresholds for every detection rule."""

    window_minutes: int = 5
    port_scan_min_ports: int = 15
    brute_force_min_attempts: int = 10
    blocked_ratio_min_events: int = 20
    blocked_ratio_threshold: float = 0.8
    exfil_min_bytes: int = 50_000_000


def _finding(rule, severity, source_ip, first_seen, last_seen, event_count, details):
    return {
        "rule": rule,
        "severity": severity,
        "source_ip": source_ip,
        "first_seen": first_seen,
        "last_seen": last_seen,
        "event_count": int(event_count),
        "details": details,
    }


def _count_status(status: pd.Series, wanted: str) -> int:
    return int((status == wanted).sum())


def detect_port_scans(work: pd.DataFrame, config: DetectionConfig) -> list[dict]:
    """One IP touching many different ports in a short time = port scan."""
    grouped = (
        work.groupby(["src_ip", "window"])
        .agg(
            ports=("dst_port", "nunique"),
            events=("dst_port", "size"),
            first_seen=("timestamp", "min"),
            last_seen=("timestamp", "max"),
        )
        .reset_index()
    )
    hits = grouped[grouped["ports"] >= config.port_scan_min_ports]
    return [
        _finding(
            "Port Scan",
            "High",
            row.src_ip,
            row.first_seen,
            row.last_seen,
            row.events,
            f"Probed {int(row.ports)} different ports within "
            f"{config.window_minutes} minutes.",
        )
        for row in hits.itertuples()
    ]


def detect_brute_force(work: pd.DataFrame, config: DetectionConfig) -> list[dict]:
    """Many connection attempts to SSH, RDP or Telnet from one IP."""
    admin = work[work["dst_port"].isin(REMOTE_ADMIN_PORTS)]
    if admin.empty:
        return []

    grouped = (
        admin.groupby(["src_ip", "window", "dst_port"])
        .agg(
            attempts=("status", "size"),
            allowed=("status", lambda s: _count_status(s, "Allowed")),
            first_seen=("timestamp", "min"),
            last_seen=("timestamp", "max"),
        )
        .reset_index()
    )
    hits = grouped[grouped["attempts"] >= config.brute_force_min_attempts]

    findings = []
    for row in hits.itertuples():
        service = SENSITIVE_PORTS.get(int(row.dst_port), str(row.dst_port))
        allowed = int(row.allowed)
        blocked = int(row.attempts) - allowed
        # If the attempts were allowed, they actually reached the service.
        severity = "Critical" if allowed > 0 else "High"
        findings.append(
            _finding(
                "Brute Force",
                severity,
                row.src_ip,
                row.first_seen,
                row.last_seen,
                row.attempts,
                f"{int(row.attempts)} connection attempts to {service} "
                f"(port {int(row.dst_port)}): {allowed} allowed, {blocked} blocked.",
            )
        )
    return findings


def detect_high_block_rate(work: pd.DataFrame, config: DetectionConfig) -> list[dict]:
    """An IP whose traffic is almost always blocked keeps hitting closed doors."""
    grouped = (
        work.groupby("src_ip")
        .agg(
            events=("status", "size"),
            blocked=("status", lambda s: _count_status(s, "Blocked")),
            first_seen=("timestamp", "min"),
            last_seen=("timestamp", "max"),
        )
        .reset_index()
    )
    grouped["ratio"] = grouped["blocked"] / grouped["events"]
    hits = grouped[
        (grouped["events"] >= config.blocked_ratio_min_events)
        & (grouped["ratio"] >= config.blocked_ratio_threshold)
    ]
    return [
        _finding(
            "High Block Rate",
            "Medium",
            row.src_ip,
            row.first_seen,
            row.last_seen,
            row.events,
            f"{int(row.blocked)} of {int(row.events)} connections "
            f"({row.ratio:.0%}) were blocked.",
        )
        for row in hits.itertuples()
    ]


def detect_data_exfiltration(work: pd.DataFrame, config: DetectionConfig) -> list[dict]:
    """An internal host sending a very large amount of data to the internet."""
    outbound = work[(work["direction"] == "Outbound") & (work["status"] == "Allowed")]
    if outbound.empty:
        return []

    grouped = (
        outbound.groupby(["src_ip", "window"])
        .agg(
            total=("bytes", "sum"),
            events=("bytes", "size"),
            first_seen=("timestamp", "min"),
            last_seen=("timestamp", "max"),
        )
        .reset_index()
    )
    hits = grouped[grouped["total"] >= config.exfil_min_bytes]
    return [
        _finding(
            "Data Exfiltration",
            "High",
            row.src_ip,
            row.first_seen,
            row.last_seen,
            row.events,
            f"Sent {row.total / 1_000_000:.1f} MB to external hosts within "
            f"{config.window_minutes} minutes.",
        )
        for row in hits.itertuples()
    ]


def detect_exposed_sensitive_ports(work: pd.DataFrame, config: DetectionConfig) -> list[dict]:
    """An internet address successfully reaching SSH, RDP, a database, etc."""
    exposed = work[
        (work["direction"] == "Inbound")
        & (work["status"] == "Allowed")
        & (work["dst_port"].isin(SENSITIVE_PORTS))
    ]
    if exposed.empty:
        return []

    grouped = (
        exposed.groupby(["src_ip", "dst_ip", "dst_port"])
        .agg(
            events=("status", "size"),
            first_seen=("timestamp", "min"),
            last_seen=("timestamp", "max"),
        )
        .reset_index()
    )
    return [
        _finding(
            "Exposed Sensitive Port",
            "High",
            row.src_ip,
            row.first_seen,
            row.last_seen,
            row.events,
            f"Reached {SENSITIVE_PORTS[int(row.dst_port)]} (port {int(row.dst_port)}) "
            f"on {row.dst_ip} from the internet. The firewall rule allows it.",
        )
        for row in grouped.itertuples()
    ]


def run_detection(df: pd.DataFrame, config: DetectionConfig | None = None) -> pd.DataFrame:
    """Run every rule and return all findings as one DataFrame."""
    config = config or DetectionConfig()
    if df.empty:
        return pd.DataFrame(columns=FINDING_COLUMNS)

    work = df.assign(window=df["timestamp"].dt.floor(f"{config.window_minutes}min"))

    findings: list[dict] = []
    findings += detect_port_scans(work, config)
    findings += detect_brute_force(work, config)
    findings += detect_high_block_rate(work, config)
    findings += detect_data_exfiltration(work, config)
    findings += detect_exposed_sensitive_ports(work, config)

    return pd.DataFrame(findings, columns=FINDING_COLUMNS)
