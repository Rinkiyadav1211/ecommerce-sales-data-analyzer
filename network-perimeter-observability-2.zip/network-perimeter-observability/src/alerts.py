"""Turn detection findings into security alerts and per-IP risk scores."""

from __future__ import annotations

import pandas as pd

from src.detector import FINDING_COLUMNS

SEVERITY_ORDER = ["Critical", "High", "Medium", "Low"]
SEVERITY_WEIGHTS = {"Critical": 40, "High": 25, "Medium": 10, "Low": 5}

ALERT_COLUMNS = ["alert_id", *FINDING_COLUMNS, "recommendation"]
RISK_COLUMNS = ["source_ip", "risk_score", "alert_count", "highest_severity", "rules"]

RECOMMENDATIONS = {
    "Port Scan": (
        "Block this IP in your firewall or network ACL, then check which of the "
        "probed ports were allowed and close any that should not be open."
    ),
    "Brute Force": (
        "Block this IP, restrict SSH/RDP to known addresses only, and make sure "
        "password logins are disabled in favour of keys or MFA."
    ),
    "High Block Rate": (
        "Review what this IP is trying to reach. Consider blocking it if the "
        "traffic is not expected."
    ),
    "Data Exfiltration": (
        "Investigate this internal host immediately: check running processes, "
        "who uses it, and where the data was sent. Isolate it if unsure."
    ),
    "Exposed Sensitive Port": (
        "Remove the rule that allows this port from the internet (for example "
        "0.0.0.0/0 in a security group) and allow only trusted addresses."
    ),
}


def build_alerts(findings: pd.DataFrame) -> pd.DataFrame:
    """Sort findings by severity and add an ID and a recommended action."""
    if findings.empty:
        return pd.DataFrame(columns=ALERT_COLUMNS)

    alerts = findings.copy()
    alerts["severity"] = pd.Categorical(
        alerts["severity"], categories=SEVERITY_ORDER, ordered=True
    )
    alerts = alerts.sort_values(
        ["severity", "last_seen"], ascending=[True, False]
    ).reset_index(drop=True)
    alerts["severity"] = alerts["severity"].astype(str)
    alerts.insert(0, "alert_id", [f"ALR-{n:04d}" for n in range(1, len(alerts) + 1)])
    alerts["recommendation"] = alerts["rule"].map(RECOMMENDATIONS).fillna(
        "Review this activity."
    )
    return alerts[ALERT_COLUMNS]


def risk_by_ip(alerts: pd.DataFrame) -> pd.DataFrame:
    """Combine all alerts for each IP into one 0-100 risk score."""
    if alerts.empty:
        return pd.DataFrame(columns=RISK_COLUMNS)

    work = alerts.assign(points=alerts["severity"].map(SEVERITY_WEIGHTS))
    grouped = (
        work.groupby("source_ip")
        .agg(
            points=("points", "sum"),
            alert_count=("alert_id", "size"),
            highest_severity=("severity", lambda s: min(s, key=SEVERITY_ORDER.index)),
            rules=("rule", lambda s: ", ".join(sorted(set(s)))),
        )
        .reset_index()
    )
    grouped["risk_score"] = grouped["points"].clip(upper=100).astype(int)
    grouped = grouped.sort_values(
        ["risk_score", "alert_count"], ascending=False
    ).reset_index(drop=True)
    return grouped[RISK_COLUMNS]
