"""Tests for src/detector.py, src/alerts.py and the planted scenarios in the sample data."""

import unittest
from pathlib import Path

from tests.helpers import make_logs, stamp
from src.alerts import build_alerts, risk_by_ip
from src.detector import DetectionConfig, run_detection
from src.log_loader import load_logs

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample_logs.csv"


def rows_for(src, dst, port, action, count, **extra):
    """`count` connections, one second apart."""
    return [
        {"timestamp": stamp(i), "src_ip": src, "dst_ip": dst, "dst_port": str(port), "action": action, **extra}
        for i in range(count)
    ]


class DetectorTests(unittest.TestCase):
    def rules(self, findings):
        return set(findings["rule"])

    def test_port_scan_is_detected(self):
        rows = [
            {"timestamp": stamp(i), "src_ip": "203.0.113.9", "dst_ip": "10.0.1.10",
             "dst_port": str(1000 + i), "action": "REJECT"}
            for i in range(20)
        ]
        findings = run_detection(make_logs(rows))
        scan = findings[findings["rule"] == "Port Scan"]
        self.assertEqual(len(scan), 1)
        self.assertEqual(scan.iloc[0]["source_ip"], "203.0.113.9")
        self.assertEqual(scan.iloc[0]["severity"], "High")

    def test_few_ports_is_not_a_port_scan(self):
        rows = [
            {"timestamp": stamp(i), "src_ip": "203.0.113.9", "dst_ip": "10.0.1.10",
             "dst_port": str(1000 + i), "action": "REJECT"}
            for i in range(5)
        ]
        findings = run_detection(make_logs(rows))
        self.assertNotIn("Port Scan", self.rules(findings))

    def test_threshold_can_be_changed(self):
        rows = [
            {"timestamp": stamp(i), "src_ip": "203.0.113.9", "dst_ip": "10.0.1.10",
             "dst_port": str(1000 + i), "action": "REJECT"}
            for i in range(5)
        ]
        findings = run_detection(make_logs(rows), DetectionConfig(port_scan_min_ports=5))
        self.assertIn("Port Scan", self.rules(findings))

    def test_allowed_ssh_attempts_are_critical(self):
        findings = run_detection(make_logs(rows_for("198.51.100.23", "10.0.1.25", 22, "ACCEPT", 12)))
        brute = findings[findings["rule"] == "Brute Force"]
        self.assertEqual(len(brute), 1)
        self.assertEqual(brute.iloc[0]["severity"], "Critical")

    def test_blocked_rdp_attempts_are_high(self):
        findings = run_detection(make_logs(rows_for("192.0.2.150", "10.0.1.10", 3389, "REJECT", 12)))
        brute = findings[findings["rule"] == "Brute Force"]
        self.assertEqual(len(brute), 1)
        self.assertEqual(brute.iloc[0]["severity"], "High")

    def test_few_ssh_attempts_are_not_brute_force(self):
        findings = run_detection(make_logs(rows_for("198.51.100.23", "10.0.1.25", 22, "REJECT", 3)))
        self.assertNotIn("Brute Force", self.rules(findings))

    def test_high_block_rate_is_detected(self):
        rows = rows_for("198.51.100.200", "10.0.1.11", 8080, "REJECT", 25)
        findings = run_detection(make_logs(rows))
        self.assertIn("High Block Rate", self.rules(findings))

    def test_mostly_allowed_traffic_is_not_high_block_rate(self):
        rows = rows_for("203.0.113.5", "10.0.1.10", 443, "ACCEPT", 30)
        rows += rows_for("203.0.113.5", "10.0.1.10", 8080, "REJECT", 3)
        findings = run_detection(make_logs(rows))
        self.assertNotIn("High Block Rate", self.rules(findings))

    def test_data_exfiltration_is_detected(self):
        rows = rows_for("10.0.2.14", "192.0.2.88", 443, "ACCEPT", 10, bytes="8000000")
        findings = run_detection(make_logs(rows))
        theft = findings[findings["rule"] == "Data Exfiltration"]
        self.assertEqual(len(theft), 1)
        self.assertEqual(theft.iloc[0]["source_ip"], "10.0.2.14")

    def test_normal_outbound_volume_is_not_exfiltration(self):
        rows = rows_for("10.0.2.14", "192.0.2.88", 443, "ACCEPT", 10, bytes="50000")
        findings = run_detection(make_logs(rows))
        self.assertNotIn("Data Exfiltration", self.rules(findings))

    def test_blocked_outbound_data_is_not_exfiltration(self):
        rows = rows_for("10.0.2.14", "192.0.2.88", 443, "REJECT", 10, bytes="8000000")
        findings = run_detection(make_logs(rows))
        self.assertNotIn("Data Exfiltration", self.rules(findings))

    def test_exposed_database_port_is_detected(self):
        findings = run_detection(make_logs(rows_for("198.51.100.77", "10.0.3.5", 3306, "ACCEPT", 2)))
        exposed = findings[findings["rule"] == "Exposed Sensitive Port"]
        self.assertEqual(len(exposed), 1)
        self.assertIn("MySQL", exposed.iloc[0]["details"])

    def test_internal_access_to_database_is_not_exposed(self):
        findings = run_detection(make_logs(rows_for("10.0.2.14", "10.0.3.5", 5432, "ACCEPT", 5)))
        self.assertNotIn("Exposed Sensitive Port", self.rules(findings))

    def test_normal_web_traffic_raises_no_findings(self):
        findings = run_detection(make_logs(rows_for("203.0.113.5", "10.0.1.10", 443, "ACCEPT", 50)))
        self.assertTrue(findings.empty)


class AlertTests(unittest.TestCase):
    def test_alerts_are_sorted_by_severity_with_ids_and_advice(self):
        rows = rows_for("198.51.100.23", "10.0.1.25", 22, "ACCEPT", 12)       # Critical + High
        rows += rows_for("198.51.100.200", "10.0.1.11", 8080, "REJECT", 25)    # Medium
        alerts = build_alerts(run_detection(make_logs(rows)))
        self.assertEqual(alerts.iloc[0]["severity"], "Critical")
        self.assertEqual(alerts.iloc[-1]["severity"], "Medium")
        self.assertEqual(alerts.iloc[0]["alert_id"], "ALR-0001")
        self.assertTrue(all(alerts["recommendation"].str.len() > 10))

    def test_no_findings_gives_empty_alerts(self):
        alerts = build_alerts(run_detection(make_logs(rows_for("203.0.113.5", "10.0.1.10", 443, "ACCEPT", 5))))
        self.assertTrue(alerts.empty)
        self.assertTrue(risk_by_ip(alerts).empty)

    def test_risk_score_adds_up_and_is_capped_at_100(self):
        rows = rows_for("198.51.100.23", "10.0.1.25", 22, "ACCEPT", 12)
        risk = risk_by_ip(build_alerts(run_detection(make_logs(rows))))
        # Critical brute force (40) + High exposed port (25) = 65
        self.assertEqual(int(risk.iloc[0]["risk_score"]), 65)
        self.assertEqual(risk.iloc[0]["highest_severity"], "Critical")
        self.assertLessEqual(int(risk["risk_score"].max()), 100)


class SampleDatasetTests(unittest.TestCase):
    def test_sample_data_triggers_exactly_the_planted_scenarios(self):
        logs = load_logs(SAMPLE).data
        findings = run_detection(logs)
        found = set(zip(findings["rule"], findings["source_ip"]))
        expected = {
            ("Port Scan", "203.0.113.66"),
            ("Brute Force", "198.51.100.23"),
            ("Brute Force", "192.0.2.150"),
            ("High Block Rate", "203.0.113.66"),
            ("High Block Rate", "192.0.2.150"),
            ("High Block Rate", "198.51.100.200"),
            ("Data Exfiltration", "10.0.2.14"),
            ("Exposed Sensitive Port", "198.51.100.23"),
            ("Exposed Sensitive Port", "198.51.100.77"),
        }
        self.assertEqual(found, expected)

    def test_sample_data_has_both_allowed_and_blocked_traffic(self):
        logs = load_logs(SAMPLE).data
        self.assertGreater((logs["status"] == "Allowed").sum(), 0)
        self.assertGreater((logs["status"] == "Blocked").sum(), 0)


if __name__ == "__main__":
    unittest.main()
