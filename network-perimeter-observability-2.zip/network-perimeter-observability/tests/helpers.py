"""Small helper used by the tests to build log DataFrames from a few fields."""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

# Make `import src...` work no matter where the tests are started from.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.log_loader import normalise_logs  # noqa: E402

BASE_TIME = datetime(2026, 10, 31, 3, 10, 0)


def stamp(seconds: int) -> str:
    """Timestamp text `seconds` after 03:10:00 on the test day."""
    return (BASE_TIME + timedelta(seconds=seconds)).strftime("%Y-%m-%d %H:%M:%S")


def make_logs(rows: list[dict]) -> pd.DataFrame:
    """Build a clean log DataFrame from rows that only need the key fields."""
    defaults = {"src_port": "40000", "protocol": "TCP", "bytes": "1000", "packets": "5"}
    records = [{**defaults, **row} for row in rows]
    raw = pd.DataFrame(records).astype(str)
    return normalise_logs(raw).data
