"""Tests for src/log_loader.py"""

import io
import unittest
from pathlib import Path

import pandas as pd

from tests.helpers import make_logs, stamp
from src.log_loader import LogFormatError, load_logs, normalise_logs

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample_logs.csv"


class LoaderTests(unittest.TestCase):
    def test_sample_file_loads_cleanly(self):
        result = load_logs(SAMPLE)
        self.assertGreater(result.rows_read, 3000)
        self.assertEqual(result.rows_dropped, 0)
        self.assertEqual(set(result.data["status"]), {"Allowed", "Blocked"})

    def test_missing_required_column_raises_clear_error(self):
        csv_text = "timestamp,src_ip,dst_ip\n2026-10-31 03:10:00,1.2.3.4,10.0.0.1\n"
        with self.assertRaises(LogFormatError) as caught:
            load_logs(io.StringIO(csv_text))
        self.assertIn("dst_port", str(caught.exception))

    def test_empty_file_raises(self):
        with self.assertRaises(LogFormatError):
            load_logs(io.StringIO(""))

    def test_header_only_file_raises(self):
        header = "timestamp,src_ip,dst_ip,dst_port,protocol,action\n"
        with self.assertRaises(LogFormatError):
            load_logs(io.StringIO(header))

    def test_invalid_rows_are_dropped_and_counted(self):
        csv_text = (
            "timestamp,src_ip,dst_ip,dst_port,protocol,action\n"
            "2026-10-31 03:10:00,203.0.113.5,10.0.1.10,443,TCP,ACCEPT\n"   # good
            "not-a-date,203.0.113.5,10.0.1.10,443,TCP,ACCEPT\n"            # bad time
            "2026-10-31 03:10:01,999.1.1.1,10.0.1.10,443,TCP,ACCEPT\n"     # bad IP
            "2026-10-31 03:10:02,203.0.113.5,10.0.1.10,99999,TCP,ACCEPT\n" # bad port
            "2026-10-31 03:10:03,203.0.113.5,10.0.1.10,443,TCP,MAYBE\n"    # bad action
        )
        result = load_logs(io.StringIO(csv_text))
        self.assertEqual(result.rows_read, 5)
        self.assertEqual(result.rows_dropped, 4)
        self.assertEqual(len(result.data), 1)

    def test_all_rows_invalid_raises(self):
        csv_text = (
            "timestamp,src_ip,dst_ip,dst_port,protocol,action\n"
            "bad,bad,bad,bad,TCP,ACCEPT\n"
        )
        with self.assertRaises(LogFormatError):
            load_logs(io.StringIO(csv_text))

    def test_action_words_map_to_allowed_and_blocked(self):
        words = {"ACCEPT": "Allowed", "allow": "Allowed", "REJECT": "Blocked", "Deny": "Blocked", "DROP": "Blocked"}
        rows = [
            {"timestamp": stamp(i), "src_ip": "203.0.113.5", "dst_ip": "10.0.1.10", "dst_port": "443", "action": word}
            for i, word in enumerate(words)
        ]
        df = make_logs(rows)
        self.assertEqual(list(df["status"]), list(words.values()))

    def test_direction_is_worked_out_from_ip_addresses(self):
        def row(src, dst, offset):
            return {"timestamp": stamp(offset), "src_ip": src, "dst_ip": dst, "dst_port": "443", "action": "ACCEPT"}

        df = make_logs([
            row("203.0.113.5", "10.0.1.10", 0),   # internet -> inside
            row("10.0.2.14", "192.0.2.88", 1),    # inside -> internet
            row("10.0.2.14", "10.0.3.5", 2),      # inside -> inside
            row("203.0.113.5", "192.0.2.88", 3),  # internet -> internet
        ])
        self.assertEqual(list(df["direction"]), ["Inbound", "Outbound", "Internal", "External"])

    def test_aws_style_columns_and_epoch_time_are_understood(self):
        epoch = int(pd.Timestamp("2026-10-31 03:10:00", tz="UTC").timestamp())
        csv_text = (
            "srcaddr,dstaddr,srcport,dstport,protocol,packets,bytes,start,action\n"
            f"203.0.113.5,10.0.1.10,50000,22,6,10,2000,{epoch},REJECT\n"
        )
        result = load_logs(io.StringIO(csv_text))
        row = result.data.iloc[0]
        self.assertEqual(row["protocol"], "TCP")
        self.assertEqual(row["status"], "Blocked")
        self.assertEqual(row["service"], "SSH")
        self.assertEqual(row["timestamp"], pd.Timestamp("2026-10-31 03:10:00", tz="UTC"))

    def test_optional_columns_default_to_zero(self):
        csv_text = (
            "timestamp,src_ip,dst_ip,dst_port,protocol,action\n"
            "2026-10-31 03:10:00,203.0.113.5,10.0.1.10,443,TCP,ACCEPT\n"
        )
        row = load_logs(io.StringIO(csv_text)).data.iloc[0]
        self.assertEqual(row["bytes"], 0)
        self.assertEqual(row["src_port"], 0)

    def test_normalise_does_not_modify_the_input(self):
        raw = pd.DataFrame(
            [{"timestamp": stamp(0), "src_ip": "203.0.113.5", "dst_ip": "10.0.1.10",
              "dst_port": "443", "protocol": "TCP", "action": "ACCEPT"}]
        )
        before = raw.copy()
        normalise_logs(raw)
        pd.testing.assert_frame_equal(raw, before)


if __name__ == "__main__":
    unittest.main()
